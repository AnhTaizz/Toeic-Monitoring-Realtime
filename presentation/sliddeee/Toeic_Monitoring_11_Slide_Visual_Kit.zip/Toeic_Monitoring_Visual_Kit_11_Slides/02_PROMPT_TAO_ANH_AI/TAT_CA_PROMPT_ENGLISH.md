# TOEIC monitoring illustration prompts — English only

# Append master style from 00_DOC_TRUOC/02_MASTER_STYLE_EN.txt to each prompt.


## S01_BIA_TONG_QUAN


Create a polished 16:9 educational technology vector illustration showing a TOEIC desktop examination system with THREE distinct functional components. Foreground center-right: a simplified student in a neutral, non-photorealistic flat/isometric style wearing headphones, sitting at a Windows desktop that displays only abstract answer-choice circles and question cards without letters. Back-middle: a compact rack-style application server with light ice-blue case and small coral status lights. Far right: a proctor at a separate monitor looking at a clean status dashboard illustrated only by rows and colored status dots. Trace CORRECT directional coral network paths from candidate computer to server and from server to proctor monitor. Keep ALL illustrated subjects within the rightmost 60% of the canvas; preserve generous empty white space on the left for a PowerPoint title. Modern corporate 2D monoline with subtle isometric perspective, consistent round navy-slate outlines, flat shading, ice-blue hardware, coral orange communication paths, pure white background, no words or numbers. Do not include cameras, face recognition, surveillance video or AI icons.



## S02_ICON_GIAM_SAT


Square isolated technical vector icon representing CENTRALIZED PROCTOR MONITORING — NOT video surveillance. One prominent proctor dashboard monitor displaying exactly three abstract candidate list rows with anonymous round avatars, tiny status bars, and contrasting status dots. Behind it, three very small candidate PC silhouettes send one-way coral data paths toward the dashboard. No security cameras, webcam frames, face detection, score predictions or suspicion verdicts. Ice-blue fills, thick rounded navy-slate linework, clean white background, ample margin, no text.



## S02_ICON_LUU_BAI


Square isolated educational vector icon representing RELIABLE EXAM ANSWER SAVING. Left: a small desktop display with four abstract circular multiple-choice marks; right: a clearly recognizable cylindrical database receiving a single small data card via a smooth coral network connection. Place a simple checkmark on the database and a small closed-padlock silhouette nearby for a finalized submission. Ice-blue flat hardware, dark rounded slate outlines, white background, minimal contrast accent in orange. No text, numbers, real brand symbols or cloud services.



## S02_ICON_TO_CHUC_THI


Square standalone vector icon for EXAM ROOM ORGANIZATION. An organized exam checklist board and a proctor desktop, with three tiny candidate computer screens arranged neatly as a mini room roster behind it. Large restrained coral check mark at the board corner. Readable silhouette at small size, simplified 2D monoline line art with a slight isometric feel, light ice-blue surfaces, thick rounded slate-blue outlines, white isolation background, generous 12% margin. No writing, no letters, no camera, no biometric hardware.



## S04_BO_THIET_BI


Create a consistent FIVE-ASSET isolated vector device icon kit, exported as FIVE SEPARATE square images (never combine as a single long image). A: ADMIN desktop with anonymous user-account cards and document icons. B: PROCTOR desktop with three rows of simple status indicators and tiny warning bell. C: CANDIDATE desktop with an abstract multiple-choice page and headphones. D: compact three-level server rack with small coral status lights. E: cylindrical database icon representing PostgreSQL storage, with abstract document records but NO brand logos. Use identical gentle isometric viewing angle (20–25 degrees), exact same thick round slate-blue strokes, flat ice-blue fills, subtle coral details, pure white or transparent background. No network cables attached. No letters, words, numbers, labels or fake interface screenshots. Each asset centered with generous padding.



## S05_BO_CANH_QUY_TRINH


Create SIX matching 4:3 frameless vector illustrations showing the accurate chronological exam workflow, as six separate files with the SAME simplified student, proctor and desktop design: (1) proctor selecting an exam document and creating a room, (2) candidate entering a five-slot room PIN with EMPTY slots, (3) candidate with headphones testing audio and receiving a check mark indicating readiness, (4) proctor starting the session via a play symbol with a timer controlled at the central server, (5) candidate choosing multiple-choice answers while one small data card moves to the server for autosaving, (6) candidate submitting while the server displays a padlock and the proctor sees a completion check. Uniform flat 2D/soft-isometric educational vector, ice-blue hardware, rounded navy-slate outlines, coral connection accents, pure white backgrounds. No numbers in slots, no prose, no words, no arbitrary extra steps, no cameras. Do NOT connect frames with baked-in arrows; leave space for editable arrows in PowerPoint.



## S06_SERVER_KHOA_BAI


Wide 16:9 educational technical vector illustration: a candidate desktop on left sending TWO separate abstract answer-version cards toward a central authoritative application server. Upper card is the accepted NEW answer version, marked by a prominent green check and a smooth coral path that reaches a database behind the server. Lower card represents an OLD late-arriving update, marked by a restrained coral stop icon at the server gate; it must NOT reach or overwrite the database. On the far right, show a finalized answer-sheet symbol with a closed padlock. Leave clean white negative space near both card tracks for editable version labels added afterwards. Flat ice-blue servers and data cards, thick rounded slate-blue contours, minimalist corporate isometric line art, no text or numerals, no fake screenshot or cybersecurity attack imagery.



## S07_FOCUS


Square standalone FOCUS CHANGE monitoring icon: a desktop screen with two clearly layered empty application windows; the top active window has a restrained coral outline and a simple cursor arrow shifting attention away from the underlying exam window. No words inside windows, no watching eye, webcam, facial recognition or user judgment. Ice-blue monitor, strong rounded slate outlines, flat white background, minimal coral.



## S07_PIPELINE_COLLECTOR


Wide minimal educational vector illustration of the TRUE monitoring pipeline. LEFT: a Windows desktop running a TOEIC exam with four isolated, non-text signal icons above it: running application processes, USB storage presence, application focus, window state. These feed into a local collector block integrated with the CANDIDATE client (not a second remote server). CENTER: a coral WebSocket data route goes to an authoritative Spring Boot application server. Beneath the server, distinguish a RAM/current-state representation and a database/history cylinder as two different storage concepts. RIGHT: a proctor dashboard with candidate status rows and event indicators, never surveillance video. Flat ice-blue hardware, thick rounded slate-blue linework, soft coral signaling, pure white, no text, no cameras or cheating verdicts. Leave text-free space for labels that will be added separately.



## S07_PROCESS


Square standalone Process monitoring icon: a small desktop display showing three overlapping blank application-window tiles, one gently highlighted with coral outline, plus a magnifying-glass silhouette examining the running-window list. This conveys process identification and filtering by name only, NOT content inspection, malware scanning or app blocking. Light ice-blue hardware, thick rounded slate-blue monoline, pure white isolated background, no text.



## S07_USB


Square isolated USB STORAGE EVENT icon: one clean simplified USB flash drive next to the USB port on a desktop chassis, with two tiny coral activity arcs to indicate presence/plug/unplug status. No file contents, folder browsing, serial numbers, spy glasses or disabled-port locks. Corporate flat 2D vector, ice-blue device, thick rounded slate-blue outline, solid white background, no text.



## S07_WINDOW


Square isolated WINDOW STATE icon: a large blank desktop application window with three small generic title-bar controls, plus a clearly smaller copy of the window beside it and one restrained curved coral downward arrow indicating minimize/window-state change. No readable user interface, no text, no lockout claim, no video monitoring, clean 2D monoline ice-blue vector on solid white.



## S10_HUONG_PHAT_TRIEN


Wide 16:9 corporate educational-tech vector illustration depicting a FUTURE VALIDATION ROADMAP, not a finished achievement. LEFT SIDE: a currently implemented TOEIC desktop Client–Server setup with one central server, three candidate PCs and a proctor screen. RIGHT SIDE: a larger, well-organized test lab of roughly 8–10 candidate PCs connecting to a similarly styled server and proctor dashboard, to represent future multi-machine evaluations. One elegant coral flow ribbon travels left to right; near the destination place small subtle icons for long-duration testing clock, reconnect/recovery circular arrows and measurement chart. Keep composition airy; ice-blue flat hardware, thick rounded navy-slate outlines, pure white background, no words, numeric claims, cameras, AI or exaggerated futuristic infrastructure.

