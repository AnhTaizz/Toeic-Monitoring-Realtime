# ẢNH CHỤP PHẦN MỀM THẬT — LINK NGUỒN

**Lưu ý:** Hình screenshot trong repository chưa được tải trực tiếp vào ZIP do môi trường tạo file không đọc được file ảnh nhị phân từ GitHub. Các link bên dưới trỏ đến đúng file gốc để mở, chọn `Download raw file` và lưu vào thư mục này. Không dùng AI để giả lập ảnh màn hình phần mềm.

## ADMIN — bảng tài khoản (slide 03)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/admin-accounts.webp
- Cách crop: Tìm ảnh có nút Thêm tài khoản, bảng danh sách; che tên thật/mật khẩu nếu có; crop vùng app, bỏ Windows taskbar.
- Nguồn / lưu ý: Từ bộ presentation hiện có, có thể là dữ liệu test.

## GIÁM THỊ — phòng READY (slide 03)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/proctor-room-ready.webp
- Cách crop: Chọn vùng danh sách thí sinh, cột Ready/Connection và nút Bắt đầu phòng thi.
- Nguồn / lưu ý: Ảnh thực tế từ GUI test, tránh nhận là phòng thi đại trà.

## THÍ SINH — bài thi Part 3 (slide 03)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/candidate-part3.webp
- Cách crop: Giữ câu hỏi, lựa chọn, điều hướng Part và số câu; không để chữ quá nhỏ khi crop.
- Nguồn / lưu ý: Cần thay Reading nếu muốn tiêu biểu hơn, ảnh này hiện là Part 3.

## PHÒNG CHỜ (slide 05)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/candidate-lobby.webp
- Cách crop: Đánh dấu khu vực tải audio, thử loa, xác nhận READY.
- Nguồn / lưu ý: Ảnh demo để minh họa luồng.

## LISTENING (slide 05)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/candidate-listening.webp
- Cách crop: Giữ thành phần giao diện phát Listening, không minh họa tua/nghe lại.
- Nguồn / lưu ý: Part Listening phát một lần theo quy tắc phiên thi.

## DASHBOARD CẢNH BÁO (slide 07)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/proctor-alerts.webp
- Cách crop: Đánh dấu 2–3 dòng tín hiệu Process/USB/Focus và phần thời gian; không che bảng.
- Nguồn / lưu ý: Không tuyên bố cảnh báo là kết luận gian lận.

## DEMO — ADMIN (slide 09)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/admin-accounts.webp
- Cách crop: Chọn một ảnh thể hiện Admin hoạt động thật, dùng ở khung phụ nhỏ.
- Nguồn / lưu ý: Chỉ dùng nếu trong slide 09 vẫn cần trình bày Admin.

## DEMO — PHÒNG CHỜ (slide 09)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/candidate-lobby.webp
- Cách crop: Lấy ảnh thí sinh trong phòng chờ sau JOIN.
- Nguồn / lưu ý: Ảnh test thực tế, phân biệt ảnh minh họa AI.

## DEMO — BÀI THI (slide 09)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/candidate-part3.webp
- Cách crop: Lấy ảnh làm bài, có câu hỏi và UI.
- Nguồn / lưu ý: Không thêm trạng thái đã lưu nếu ảnh thực tế không có.

## DEMO — CẢNH BÁO (slide 09)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/proctor-alerts.webp
- Cách crop: Lấy ảnh giám thị có cảnh báo, đặt làm ảnh chính.
- Nguồn / lưu ý: Ảnh chụp không phải ảnh AI.

## ADMIN — SOẠN ĐỀ (slide 03)
- Mở ảnh: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/assets/screens/admin-manual-exam.png
- Cách crop: Tùy chọn nếu muốn nhấn mạnh chức năng quản lý đề.
- Nguồn / lưu ý: Ảnh công cụ test; không nên gộp thêm vào slide gây rối.
