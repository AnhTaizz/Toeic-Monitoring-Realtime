# SLIDE 07 — GIÁM SÁT REALTIME

**Dạng ảnh:** Ảnh giám thị thật + sơ đồ/4 icon AI

**Vị trí / diện tích hình (khung 16:9):** Phía trái 55% sơ đồ pipeline, phía phải 45% dashboard giám thị; hoặc đặt 4 icon lớn trên cùng, screenshot lớn phía dưới. Sự kiện không phải kết luận gian lận.

**Asset cần đưa vào:** S07_PROCESS/USB/FOCUS/WINDOW; 07_GIAM_SAT_PIPELINE.png; screenshot proctor-alerts.webp

**Chữ nên xuất hiện trên SLIDE (rất ít):** PROCESS | USB | FOCUS | WINDOW

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói local Collector quét process, signal adapters, WebSocket, trạng thái hiện tại trong RAM và lịch sử trong DB.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
