# SLIDE 08 — KIỂM THỬ VÀ THỰC NGHIỆM

**Dạng ảnh:** Biểu đồ số liệu thật

**Vị trí / diện tích hình (khung 16:9):** Tập trung tối đa 3 KPI lớn và 1 biểu đồ 2 màu. Số liệu từ Word 27–28/10/2026. Không nhồi giải thích phép thử vào slide; chú thích phạm vi rất nhỏ.

**Asset cần đưa vào:** 08_FULL_VS_DELTA.png; 08_POLLING_CPU.png

**Chữ nên xuất hiện trên SLIDE (rất ít):** 363 CA ĐẠT | 68,34%* | 20 CLIENT GIẢ LẬP

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói 363 PASS 4 SKIP server, E2 ít thay đổi delta giảm 68,34% byte WS, benchmark 20 client giả lập.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
