# SLIDE 01 — GIỚI THIỆU

**Dạng ảnh:** Ảnh AI bìa

**Vị trí / diện tích hình (khung 16:9):** Bên trái 45–50% chữ; bên phải 50–55% hình. Tiêu đề tối đa 2–3 dòng; logo học viện và tên nhóm do designer thêm riêng. Không đưa toàn bộ tên thành viên lên 1 hàng quá dài.

**Asset cần đưa vào:** 01 ảnh 16:9: S01_BIA_TONG_QUAN

**Chữ nên xuất hiện trên SLIDE (rất ít):** Chỉ đặt: TOEIC MONITOR; Thi TOEIC Client–Server & giám sát thời gian thực; Nhóm 03; thành viên nhỏ phía dưới.

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói ngắn: bài toán tổ chức thi + giám sát trên ứng dụng desktop, không có camera.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
