# SLIDE 03 — CHỨC NĂNG — 3 VAI TRÒ

**Dạng ảnh:** 3 ảnh chụp phần mềm THẬT

**Vị trí / diện tích hình (khung 16:9):** Ba ảnh thật cạnh nhau, cùng tỉ lệ 4:3 hoặc cắt 16:10, có khung trắng bo 24 px. Mỗi ảnh có đúng một nhãn lớn bên dưới. Không thêm list chức năng.

**Asset cần đưa vào:** GITHUB: admin-accounts.webp; proctor-room-ready.webp; candidate-part3.webp

**Chữ nên xuất hiện trên SLIDE (rất ít):** ADMIN | GIÁM THỊ | THÍ SINH

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói vai trò theo luồng sử dụng. Server xác thực phân quyền; một ứng dụng JavaFX cho cả 3 vai trò.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
