# SLIDE 02 — BÀI TOÁN — 3 NHU CẦU

**Dạng ảnh:** 3 icon AI đồng bộ

**Vị trí / diện tích hình (khung 16:9):** Tiêu đề ngắn ở đầu. Ba cột ngang bằng nhau; mỗi icon vuông chiếm 60–65% chiều cao cột; dưới là đúng 1 nhãn tối đa 4 từ. Cân vị trí giữa các icon.

**Asset cần đưa vào:** S02_ICON_TO_CHUC_THI + S02_ICON_LUU_BAI + S02_ICON_GIAM_SAT

**Chữ nên xuất hiện trên SLIDE (rất ít):** TỔ CHỨC THI | BẢO TOÀN BÀI LÀM | GIÁM SÁT TẬP TRUNG

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói lý do: phòng thi nhiều client; save/submit cạnh tranh; dữ liệu quan sát và mất kết nối.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
