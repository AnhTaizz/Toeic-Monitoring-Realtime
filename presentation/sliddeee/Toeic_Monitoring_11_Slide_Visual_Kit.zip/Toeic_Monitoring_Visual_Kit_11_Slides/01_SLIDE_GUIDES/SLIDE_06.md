# SLIDE 06 — LƯU/NỘP BÀI AN TOÀN

**Dạng ảnh:** Sơ đồ revision + transaction

**Vị trí / diện tích hình (khung 16:9):** Dùng sơ đồ 2 làn: bản mới được lưu và bản cũ đến muộn bị chặn; khóa kết quả sau nộp. Có thể dùng SVG sẵn, không cần code dài.

**Asset cần đưa vào:** 06_NHAT_QUAN_BAI_LAM.png; S06_SERVER_KHOA_BAI

**Chữ nên xuất hiện trên SLIDE (rất ít):** REVISION 12 ✓ | REVISION 11 ✕ | SUBMITTED 🔒

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói writerEpoch, answerRevision, requestId, transaction, row lock, server không ACK trước commit.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
