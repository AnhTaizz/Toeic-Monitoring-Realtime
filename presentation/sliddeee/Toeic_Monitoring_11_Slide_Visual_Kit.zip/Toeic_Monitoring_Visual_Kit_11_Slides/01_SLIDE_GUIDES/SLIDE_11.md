# SLIDE 11 — CODE TRỌNG TÂM — MONITORING

**Dạng ảnh:** Code thật + sơ đồ

**Vị trí / diện tích hình (khung 16:9):** Đặt khối code 35–40% bên trái; sơ đồ 60–65% bên phải. Chỉ 3 dòng code từ ProcessCollector.java, font mono 22–25pt trên slide Full HD. Có thể đưa link GitHub dưới cùng.

**Asset cần đưa vào:** 11_CODE_COLLECTOR.png; 11_LUONG_CODE_MONITORING.png

**Chữ nên xuất hiện trên SLIDE (rất ít):** PROCESSHANDLE → COLLECTOR → WEBSOCKET → SERVER

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói scheduleWithFixedDelay, worker riêng, scan và callback; delivery/realtime tách collector; server cập nhật monitoring.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
