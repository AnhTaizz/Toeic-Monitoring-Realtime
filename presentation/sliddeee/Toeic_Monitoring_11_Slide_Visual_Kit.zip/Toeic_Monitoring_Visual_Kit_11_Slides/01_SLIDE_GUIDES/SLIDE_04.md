# SLIDE 04 — KIẾN TRÚC CLIENT–SERVER

**Dạng ảnh:** Sơ đồ SVG/PNG dựng sẵn

**Vị trí / diện tích hình (khung 16:9):** Sơ đồ chiếm 85–90% thân slide. Ba client hàng trên; hai loại kênh; server hàng giữa; PostgreSQL/Media hàng dưới. Màu cho đường REST khác đường WebSocket.

**Asset cần đưa vào:** 03_SO_DO_KY_THUAT_PNG/04_KIEN_TRUC_CLIENT_SERVER.png

**Chữ nên xuất hiện trên SLIDE (rất ít):** ADMIN | GIÁM THỊ | THÍ SINH | REST | WEBSOCKET | SPRING BOOT | POSTGRESQL

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói HTTP yêu cầu/đáp ứng, WebSocket push 2 chiều, server quyết định dữ liệu và deadline.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
