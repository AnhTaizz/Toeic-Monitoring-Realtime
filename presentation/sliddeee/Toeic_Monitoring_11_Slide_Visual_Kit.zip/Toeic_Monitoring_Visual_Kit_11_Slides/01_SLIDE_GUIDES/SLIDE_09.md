# SLIDE 09 — DEMO PHẦN MỀM

**Dạng ảnh:** Screenshot 100% từ JavaFX

**Vị trí / diện tích hình (khung 16:9):** Một ảnh giám thị thật lớn (60%), 2 ảnh thí sinh bên phải (40%). Chỉ dùng viền khoanh 3 vùng trên screenshot, không bịa icon màn hình. Ghi DATA TEST nếu mock.

**Asset cần đưa vào:** GITHUB: proctor-alerts.webp, candidate-lobby.webp, candidate-part3.webp, candidate-listening.webp

**Chữ nên xuất hiện trên SLIDE (rất ít):** PHÒNG CHỜ | LÀM BÀI | CẢNH BÁO

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói hoặc demo nhanh một phòng PIN, READY, START, autosave, process/USB, submit.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
