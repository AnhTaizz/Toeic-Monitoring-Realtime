# SLIDE 05 — QUY TRÌNH THI

**Dạng ảnh:** Storyboard AI hoặc sơ đồ SVG/PNG

**Vị trí / diện tích hình (khung 16:9):** Dùng một timeline 6 bước rất to chiếm 80%. Nếu dùng storyboard ảnh AI: sáu cảnh đồng bộ, mỗi cảnh có một nhãn 1–2 từ. Không đặt ảnh giao diện thật quá nhỏ.

**Asset cần đưa vào:** S05_BO_CANH_QUY_TRINH; 05_QUY_TRINH_THI.png; screenshot candidate-lobby.webp

**Chữ nên xuất hiện trên SLIDE (rất ít):** TẠO PHÒNG → PIN → READY → START → LÀM BÀI → NỘP

**Phần người thuyết trình cần GIẢI THÍCH, KHÔNG chép lên slide:** Nói kiểm checksum, test loa, Listening một lần, deadline server, autosave/submit.

**Chú ý kỹ thuật:** Tất cả đường truyền và chức năng phải phù hợp hệ thống thật. Hình AI không được có chữ, logo hoặc camera. Ảnh giao diện phải lấy từ phần mềm/test đã tồn tại và chú thích nguồn.
