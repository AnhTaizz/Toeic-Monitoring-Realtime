# TOEIC Monitoring Realtime — Visual Assets Kit cho 11 slide

**Mục đích:** Bộ tư liệu đưa cho người làm PowerPoint/Canva và người tạo hình minh họa. Mọi giải thích dài nằm ngoài slide; slide trình bày chủ yếu bằng hình. Nội dung bám báo cáo Word nhóm 03 và mã nguồn GitHub Toeic-Monitoring-Realtime.

## CÁCH SỬ DỤNG NHANH

1. Giải nén toàn bộ ZIP.
2. Mở **HUONG_DAN_TRUC_QUAN.html** trong Chrome hoặc Edge (hoạt động ngoại tuyến; trừ link xem ảnh GitHub).
3. Nếu muốn dùng ngay: mở **03_SO_DO_KY_THUAT_PNG/** và chèn các ảnh PNG vào slide. Nếu cần đổi chữ/màu/khối: dùng **04_SO_DO_KY_THUAT_SVG/**.
4. Nếu giao cho bạn tạo ảnh AI: gửi nguyên file `.txt` phù hợp trong **02_PROMPT_TAO_ANH_AI/SLIDE_xx/**; mỗi prompt gồm VN + EN + negative prompt + quy tắc để chữ ra ngoài ảnh.
5. Đối với các slide cần ảnh ứng dụng thật: mở **06_LINK_ANH_PHAN_MEM/LINK_ANH_THAT_VA_HUONG_DAN_CHUP.md** rồi tải ảnh gốc GitHub, hoặc tự chụp bản phần mềm nhóm đang chạy.
6. Mở **01_SLIDE_GUIDES/SLIDE_xx.md** để biết ghép hình vào vùng nào và slide chỉ cần ghi các nhãn nào.

## NHỮNG FILE ĐÃ CÓ THẬT TRONG ZIP

- **9 ảnh PNG dùng ngay**: 8 sơ đồ/khung hình kỹ thuật + 1 thẻ code ngắn.
- **8 SVG có thể chỉnh sửa**: kiến trúc, quy trình, nhất quán, giám sát, số liệu FULL/DELTA, CPU, code pipeline, khung screenshot.
- **2 hình gốc trích từ báo cáo Word**: Hình 4.1 và Hình 4.2, dùng để đối chiếu.
- **13 prompt AI rất chi tiết** và **11 bản hướng dẫn dàn slide**.
- File link và hướng dẫn chụp **11 tham chiếu ảnh screenshot thật** từ repository.

## ĐIỂM CẦN TRUNG THỰC KHI TRÌNH BÀY

Ảnh screenshot phần mềm trên GitHub được CẤP LINK và hướng dẫn chụp, không chứa trực tiếp trong ZIP do môi trường tạo file không thể tải bản nhị phân từ GitHub. Đừng gọi các ảnh sơ đồ là ảnh chụp phần mềm. Các ảnh AI chưa được tạo, nên prompt là bản chỉ dẫn để bạn thiết kế tạo sau.

Các đồ thị từ Bảng 5.3, 5.4 trong Word: E1 quét tiến trình với nhiều chu kỳ và E2 FULL vs DELTA. Một số slide cũ tại presentation sử dụng kết quả ở các đợt kiểm thử khác nhau; không tự ý gộp chung số liệu của hai đợt.

## NGUỒN

- Repository: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime
- Slide HTML cũ: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/tree/main/presentation
- Thiết kế cũ: https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/main/presentation/DESIGN_SYSTEM.md
- Bộ tài liệu này cũng dựa trên Hình 4.1, Hình 4.2 và Bảng 5.3–5.5 trong báo cáo Word được người dùng cung cấp.
