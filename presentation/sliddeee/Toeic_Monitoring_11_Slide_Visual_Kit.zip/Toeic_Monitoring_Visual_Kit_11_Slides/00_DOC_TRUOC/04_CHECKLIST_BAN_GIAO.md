# CHECKLIST BÀN GIAO CHO NGƯỜI THIẾT KẾ

- [ ] Dùng đúng khung 16:9; mọi ảnh chính 1920×1080, icon vuông 1024×1024 trở lên.
- [ ] Tài liệu trong bộ ZIP là PROMPT và CÁCH DÀN, không chép prompt dài lên slide.
- [ ] Slide 01: Tạo ảnh S01_BIA_TONG_QUAN; chừa khoảng bên trái đặt tiêu đề.
- [ ] Slide 02: Tạo ba icon S02 đồng nhất, dùng tối đa ba nhãn.
- [ ] Slide 03: Tải ảnh thật Admin / Giám thị / Thí sinh ở thư mục 06; không dùng AI tạo UI giả.
- [ ] Slide 04: Dùng PNG 04_KIEN_TRUC_CLIENT_SERVER.png, nếu cần sửa thì mở SVG tương ứng.
- [ ] Slide 05: Dùng 05_QUY_TRINH_THI.png hoặc tạo bộ sáu cảnh S05.
- [ ] Slide 06: Dùng 06_NHAT_QUAN_BAI_LAM.png hoặc ảnh S06; thêm nhãn Revision bằng PPT.
- [ ] Slide 07: Dùng 07_GIAM_SAT_PIPELINE.png, thêm screenshot proctor-alerts.webp tải từ GitHub.
- [ ] Slide 08: Dùng 08_FULL_VS_DELTA.png hoặc 08_POLLING_CPU.png; không bịa số liệu.
- [ ] Slide 09: Lấy ba screenshot thật và ghép theo khung 09_KHUNG_GHEP_ANH_THAT.png.
- [ ] Slide 10: Tạo S10_HUONG_PHAT_TRIEN, diễn đạt rõ là định hướng, chưa phải thành quả.
- [ ] Slide 11: Dùng 11_CODE_COLLECTOR.png và 11_LUONG_CODE_MONITORING.png.
- [ ] Ảnh AI KHÔNG chứa chữ, webcam, camera, AI nhận diện mặt, màn hình giả làm bằng chứng.
- [ ] Ảnh chụp không lộ password, token, mã phòng còn hiệu lực hay dữ liệu nhạy cảm.
- [ ] Chỉ 1 ý chính/slide, tối đa vài nhãn ngắn. Ảnh chiếm 75–85% diện tích.
- [ ] Phân biệt demo dữ liệu TEST/MOCK với thử nghiệm trên nhiều máy vật lý.
- [ ] Người thuyết trình học trong 01_SLIDE_GUIDES, không đưa giải thích dài lên slide.
